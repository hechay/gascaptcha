import os
import uuid
import base64
from flask import Flask, request, jsonify

app = Flask(__name__)
port = 9999

# Middleware to log remote IP address
@app.before_request
def log_remote_ip():
    remote_ip = request.remote_addr
    print(f"Request from Remote IP: {remote_ip}")

@app.route('/getIP', methods=['GET'])
def get_ip():
    remote_ip = request.remote_addr
    return f"Remote IP: {remote_ip}"

@app.route('/upload', methods=['POST'])
def upload():
    image_data = request.data
    if not image_data:
        return 'Bad Request: Image data not provided', 400

    # Generate a random filename with a timestamp
    file_name = f"{uuid.uuid4()}.png"
    file_path = os.path.join('captcha', file_name)

    # Write the image data to the file
    try:
        with open(file_path, 'wb') as file:
            file.write(image_data)
        return f"OK|{file_name}", 200
    except Exception as e:
        print(f"Error: {e}")
        return 'Internal Server Error', 500

@app.route('/getID', methods=['GET'])
def get_id():
    name = request.args.get('name')
    if not name:
        return 'Bad Request: Missing "name" parameter', 400

    result_file_path = os.path.join('result', f"{name}.txt")

    # Check if the file exists
    if os.path.exists(result_file_path):
        # Read the content of the file
        try:
            with open(result_file_path, 'r') as file:
                data = file.read()
            os.remove(result_file_path)  # Delete the file
            return f"OK|{data}", 200
        except Exception as e:
            print(f"Error: {e}")
            return 'Internal Server Error', 500
    else:
        return '0', 200

@app.route('/getCaptcha', methods=['GET'])
def get_captcha():
    captcha_folder = os.path.join(os.getcwd(), 'captcha')
    captcha_data = []

    # Read the files in the captcha folder
    try:
        # Get a list of captcha files with their creation times
        captcha_files = [(file_name, os.path.getctime(os.path.join(captcha_folder, file_name)))
                         for file_name in os.listdir(captcha_folder)]

        # Sort the captcha files by creation time in ascending order (oldest first)
        captcha_files.sort(key=lambda x: x[1])

        # Read and encode the captcha files as base64
        for file_name, _ in captcha_files:
            file_path = os.path.join(captcha_folder, file_name)
            with open(file_path, 'rb') as file:
                file_data = base64.b64encode(file.read()).decode('utf-8')
                captcha_data.append({'name': file_name, 'data': file_data})

        return jsonify(captcha_data), 200
    except Exception as e:
        print(f"Error: {e}")
        return 'Internal Server Error', 500

@app.route('/update', methods=['POST'])
def update():
    name = request.form.get('name')
    result = request.form.get('result')

    if not name or not result:
        return 'Bad Request: Missing name or result', 400

    result_directory = 'result'
    if not os.path.exists(result_directory):
        os.mkdir(result_directory)

    result_file_path = os.path.join(result_directory, f"{name}.txt")

    # Write the result to the file
    try:
        with open(result_file_path, 'w') as file:
            file.write(result)
        os.remove(os.path.join('captcha', name))
        return 'Result saved successfully', 200
    except Exception as e:
        print(f"Error: {e}")
        return 'Internal Server Error', 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port)
