import cv2
import typing
import numpy as np
import os
import random
import time
import requests
import base64
import time

from mltu.inferenceModel import OnnxInferenceModel
from mltu.utils.text_utils import ctc_decoder, get_cer

class ImageToWordModel(OnnxInferenceModel):
    def __init__(self, char_list: typing.Union[str, list], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.char_list = char_list

    def predict(self, image: np.ndarray):
        # Check if the image is None or has a size of 0.
        if image is None or image.size == 0:
            # Return the default string if the image is not valid.
            return "ABCDE"
        image = cv2.resize(image, self.input_shape[:2][::-1])
        image_pred = np.expand_dims(image, axis=0).astype(np.float32)
        preds = self.model.run(None, {self.input_name: image_pred})[0]
        text = ctc_decoder(preds, self.char_list)[0]
        return text

if __name__ == "__main__":
    server = "127.0.0.1"
    port   = "9999"
    print("Server: " + server + ":" + port)
    from mltu.configs import BaseModelConfigs
    configs = BaseModelConfigs.load("./Models/202311070537/configs.yaml")
    model = ImageToWordModel(model_path=configs.model_path, char_list=configs.vocab)
    while True:
        time.sleep(1)
        url = 'http://' + server + ':' + port +'/getCaptcha'
        # Send a GET request to retrieve captcha items
        response = requests.get(url)
        total = 0
        if response.status_code == 200:
            captcha_data = response.json()
            num_captchas = len(captcha_data)
            print(f"Received {num_captchas} captcha items")
            solving_directory = 'solving'
            if not os.path.exists(solving_directory):
                os.makedirs(solving_directory)
            start_time = time.time()
            for item in captcha_data:
                name = item['name']
                base64_data = item['data']
                # Decode the base64 data
                image_data = base64.b64decode(base64_data)
                # Save the decoded data to the solving directory
                file_path = os.path.join(solving_directory, name)
                with open(file_path, 'wb') as file:
                    file.write(image_data)
                if os.path.exists(file_path):
                    # Get the size of the file in bytes
                    file_size_bytes = os.path.getsize(file_path)                
                    # Convert the size to kilobytes (KB)
                    file_size_kb = file_size_bytes / 1024  # 1 KB = 1024 bytes
                    # Check if the file size is under 3000 KB
                    if file_size_kb < 2:
                        print("File size " + name + " is too small: " , file_size_kb )
                        continue
                    if file_size_kb > 6:
                        print("File size " + name + " is too big: " , file_size_kb )
                        continue
                image = cv2.imread( file_path )
                result = model.predict(image)
                os.remove(file_path)
                print(name + " = " + result)  
                url = 'http://' + server + ':' + port + '/update'
                data = {
                    'name': name,
                    'result': result
                }
                response = requests.post(url, data=data)
                # Check the response
                if response.status_code == 200:
                    print('POST request successful')
                else:
                    print(f'POST request failed. Status code: {response.status_code}')
                total = total + 1
            if total != 0:
                end_time = time.time()
                time_spent = end_time - start_time
                print(f"Time spent in the loop: {time_spent:.2f} seconds")
                time_solve_each = time_spent / total
                print(f"Average time spent on each captcha: {time_solve_each:.2f} seconds")